const mongoose = require('mongoose');

module.exports = mongoose.model('Complaint', new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true, trim: true },
  desc: { type: String, required: true, trim: true },
  category: { type: String, enum: ['Electrical', 'Plumbing', 'Internet', 'Furniture', 'Cleaning', 'Other'], default: 'Other' },
  status: { type: String, enum: ['pending', 'in-progress', 'resolved'], default: 'pending' }
}, { timestamps: true }));
