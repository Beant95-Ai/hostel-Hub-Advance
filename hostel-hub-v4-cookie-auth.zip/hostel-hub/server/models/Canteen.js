const mongoose = require('mongoose');

const MessMenu = mongoose.model('MessMenu', new mongoose.Schema({
  day: { type: String, enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], unique: true },
  breakfast: String, lunch: String, dinner: String
}));

const FoodItem = mongoose.model('FoodItem', new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, trim: true },
  category: { type: String, enum: ['Snacks', 'Meals', 'Beverages', 'Desserts', 'Essentials'], default: 'Snacks' },
  price: { type: Number, required: true, min: 0 },
  image: String,          // uploaded file name (uploads/food) or a full https:// photo URL
  available: { type: Boolean, default: true }
}, { timestamps: true }));

const Order = mongoose.model('Order', new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  roomLabel: String,
  items: [{ food: { type: mongoose.Schema.Types.ObjectId, ref: 'FoodItem' }, name: String, price: Number, qty: Number }],
  total: Number,
  note: { type: String, trim: true },
  payment: {
    method: { type: String, enum: ['upi', 'card', 'cod'], default: 'cod' },
    status: { type: String, enum: ['pending', 'paid', 'refunded'], default: 'pending' },
    txnId: String,          // demo transaction id
    ref: String,            // UPI id or "Card •••• 1234" (never the full card number)
    paidAt: Date
  },
  status: { type: String, enum: ['placed', 'preparing', 'ready', 'delivered', 'cancelled'], default: 'placed' }
}, { timestamps: true }));

module.exports = { MessMenu, FoodItem, Order };
