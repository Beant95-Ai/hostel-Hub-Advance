const mongoose = require('mongoose');

const Machine = mongoose.model('LaundryMachine', new mongoose.Schema({
  name: { type: String, required: true, trim: true }
}));

const Booking = mongoose.model('LaundryBooking', new mongoose.Schema({
  machine: { type: mongoose.Schema.Types.ObjectId, ref: 'LaundryMachine', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  start: { type: Date, required: true },
  end: { type: Date, required: true }
}, { timestamps: true }));

module.exports = { Machine, Booking };
