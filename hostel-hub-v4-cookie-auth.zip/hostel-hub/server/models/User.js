const mongoose = require('mongoose');

module.exports = mongoose.model('User', new mongoose.Schema({
  rollNo: { type: String, required: true, unique: true, uppercase: true, trim: true },
  name: { type: String, required: true, trim: true },
  role: { type: String, enum: ['student', 'warden', 'admin'], default: 'student' },
  password: { type: String, required: true, select: false },
  phone: { type: String, trim: true },
  email: { type: String, trim: true, lowercase: true },
  course: { type: String, trim: true },
  year: { type: String, trim: true },
  guardianName: { type: String, trim: true },
  guardianPhone: { type: String, trim: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', default: null },
  idCard: { filename: String, originalName: String, mimetype: String, uploadedAt: Date }
}, { timestamps: true }));
