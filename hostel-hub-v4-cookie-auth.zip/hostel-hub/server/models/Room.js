const mongoose = require('mongoose');

module.exports = mongoose.model('Room', new mongoose.Schema({
  number: { type: String, required: true, unique: true, trim: true },
  block: { type: String, required: true, trim: true },
  floor: { type: Number, default: 0 },
  type: { type: String, enum: ['Non-AC', 'AC'], default: 'Non-AC' },
  capacity: { type: Number, default: 3, min: 1, max: 6 },
  occupants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true }));
