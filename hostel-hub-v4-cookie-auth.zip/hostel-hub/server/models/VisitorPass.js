const mongoose = require('mongoose');

module.exports = mongoose.model('VisitorPass', new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  visitorName: { type: String, required: true, trim: true },
  visitorPhone: { type: String, required: true, trim: true },
  visitDate: { type: String, required: true },
  purpose: { type: String, required: true, trim: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' }
}, { timestamps: true }));
