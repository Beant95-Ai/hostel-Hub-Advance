const mongoose = require('mongoose');

module.exports = mongoose.model('Notice', new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  desc: { type: String, required: true, trim: true },
  category: { type: String, enum: ['notice', 'circular', 'urgent'], default: 'notice' },
  by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  attachment: { filename: String, originalName: String, mimetype: String }
}, { timestamps: true }));
