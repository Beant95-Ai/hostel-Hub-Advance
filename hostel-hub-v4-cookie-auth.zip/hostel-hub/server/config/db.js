const mongoose = require('mongoose');

module.exports = async function connectDB() {
  const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hostel_hub';
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 8000 });
  } catch (e) {
    console.error('\n  Could not reach MongoDB at', uri.replace(/\/\/[^@]*@/, '//***@'));
    console.error('  - Local MongoDB: make sure the "MongoDB" Windows service is running (net start MongoDB as Administrator).');
    console.error('  - Atlas: check MONGO_URI in server/.env and that your IP is allowed in Network Access.\n');
    throw e;
  }
  console.log('MongoDB connected:', mongoose.connection.host, '/', mongoose.connection.name);
};
