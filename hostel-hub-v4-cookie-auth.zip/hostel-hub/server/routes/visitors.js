const router = require('express').Router();
const VisitorPass = require('../models/VisitorPass');
const { protect, staff, authorize } = require('../middleware/auth');
const notify = require('../utils/notify');

router.use(protect);

router.get('/', async (req, res) => {
  const filter = req.user.role === 'student' ? { student: req.user._id } : {};
  res.json(await VisitorPass.find(filter).populate('student', 'name rollNo').sort({ createdAt: -1 }));
});

router.post('/', authorize('student'), async (req, res) => {
  const { visitorName, visitorPhone, visitDate, purpose } = req.body;
  if (!visitorName || !visitorPhone || !visitDate || !purpose) return res.status(400).json({ message: 'All fields are required.' });
  const p = await VisitorPass.create({ student: req.user._id, visitorName, visitorPhone, visitDate, purpose });
  notify(req, 'visitors');
  res.status(201).json(p);
});

router.patch('/:id', staff, async (req, res) => {
  if (!['approved', 'rejected'].includes(req.body.status)) return res.status(400).json({ message: 'Invalid status.' });
  const p = await VisitorPass.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!p) return res.status(404).json({ message: 'Pass not found.' });
  notify(req, 'visitors');
  res.json(p);
});

module.exports = router;
