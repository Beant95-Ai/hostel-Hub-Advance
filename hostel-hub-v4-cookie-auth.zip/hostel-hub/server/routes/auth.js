const router = require('express').Router();
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const { protect, signToken, setAuthCookie, clearAuthCookie } = require('../middleware/auth');
const upload = require('../middleware/upload');

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, message: { message: 'Too many attempts. Try again in a few minutes.' } });
const populated = (id) => User.findById(id).populate('room', 'number block floor type');

// Sign up (students, wardens and admins — staff just use their staff number, no code needed)
router.post('/register', upload.idCard.single('idCard'), async (req, res) => {
  const cleanup = () => req.file && upload.remove('idcards', req.file.filename);
  const { name, rollNo, password, phone, role = 'student', course, year, email } = req.body;
  if (!name || !rollNo || !password) { cleanup(); return res.status(400).json({ message: 'Name, roll number and password are required.' }); }
  if (password.length < 6) { cleanup(); return res.status(400).json({ message: 'Password must be at least 6 characters.' }); }
  if (!['student', 'warden', 'admin'].includes(role)) { cleanup(); return res.status(400).json({ message: 'Invalid role.' }); }
  if (await User.exists({ rollNo: rollNo.toUpperCase().trim() })) {
    cleanup(); return res.status(409).json({ message: 'This roll / staff number is already registered.' });
  }
  const user = await User.create({
    name, rollNo, phone, role, course, year, email,
    password: await bcrypt.hash(password, 10),
    ...(req.file && { idCard: { filename: req.file.filename, originalName: req.file.originalname, mimetype: req.file.mimetype, uploadedAt: new Date() } })
  });
  req.app.get('io').emit('update', { type: 'users' });
  setAuthCookie(res, signToken(user));            // JWT -> cookie
  res.status(201).json({ user: await populated(user._id) });
});

router.post('/login', loginLimiter, async (req, res) => {
  const { rollNo, password } = req.body;
  const user = await User.findOne({ rollNo: String(rollNo || '').toUpperCase().trim() }).select('+password');
  if (!user || !(await bcrypt.compare(password || '', user.password)))
    return res.status(401).json({ message: 'Roll number or password is incorrect.' });
  setAuthCookie(res, signToken(user));            // JWT -> cookie
  res.json({ user: await populated(user._id) });
});

// Logout: delete the cookie
router.post('/logout', (req, res) => {
  clearAuthCookie(res);
  res.json({ message: 'Logged out.' });
});

router.get('/me', protect, async (req, res) => res.json(await populated(req.user._id)));

router.put('/me', protect, async (req, res) => {
  const allowed = ['phone', 'email', 'course', 'year', 'guardianName', 'guardianPhone'];
  allowed.forEach((k) => { if (req.body[k] !== undefined) req.user[k] = req.body[k]; });
  await req.user.save();
  res.json(await populated(req.user._id));
});

router.put('/password', protect, async (req, res) => {
  const { current, next } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  if (!(await bcrypt.compare(current || '', user.password))) return res.status(400).json({ message: 'Current password is wrong.' });
  if (!next || next.length < 6) return res.status(400).json({ message: 'New password must be at least 6 characters.' });
  user.password = await bcrypt.hash(next, 10);
  await user.save();
  res.json({ message: 'Password updated.' });
});

module.exports = router;
