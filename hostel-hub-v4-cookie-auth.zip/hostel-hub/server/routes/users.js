const router = require('express').Router();
const path = require('path');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Room = require('../models/Room');
const { protect, staff, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const notify = require('../utils/notify');

router.use(protect);

// Student directory (wardens/admin): live data from MongoDB
router.get('/', staff, async (req, res) => {
  const { role, q, unallotted } = req.query;
  const filter = {};
  if (role) filter.role = role;
  if (unallotted === '1') filter.room = null;
  if (q) {
    const rx = new RegExp(String(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    filter.$or = [{ name: rx }, { rollNo: rx }, { course: rx }];
  }
  res.json(await User.find(filter).populate('room', 'number block').sort({ createdAt: -1 }));
});

// Admin creates staff accounts directly
router.post('/', authorize('admin'), async (req, res) => {
  const { name, rollNo, password, phone, role } = req.body;
  if (!name || !rollNo || !password || !['warden', 'admin'].includes(role))
    return res.status(400).json({ message: 'Name, staff number, password and role are required.' });
  if (await User.exists({ rollNo: rollNo.toUpperCase().trim() })) return res.status(409).json({ message: 'Already registered.' });
  const u = await User.create({ name, rollNo, phone, role, password: await bcrypt.hash(password, 10) });
  notify(req, 'users');
  res.status(201).json(u);
});

router.delete('/:id', authorize('admin'), async (req, res) => {
  if (String(req.user._id) === req.params.id) return res.status(400).json({ message: 'You cannot remove yourself.' });
  const u = await User.findByIdAndDelete(req.params.id);
  if (!u) return res.status(404).json({ message: 'User not found.' });
  await Room.updateMany({ occupants: u._id }, { $pull: { occupants: u._id } });
  upload.remove('idcards', u.idCard?.filename);
  notify(req, 'users'); notify(req, 'rooms');
  res.json({ message: 'User removed.' });
});

// ID card upload (multer) - a student uploads / replaces own card
router.post('/me/idcard', authorize('student'), upload.idCard.single('idCard'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Choose a JPG, PNG, WEBP or PDF file (max 2 MB).' });
  upload.remove('idcards', req.user.idCard?.filename);
  req.user.idCard = { filename: req.file.filename, originalName: req.file.originalname, mimetype: req.file.mimetype, uploadedAt: new Date() };
  await req.user.save();
  notify(req, 'users');
  res.json(req.user);
});

// ID card download: only the owner or staff (files are NOT publicly served)
router.get('/:id/idcard', async (req, res) => {
  const isStaff = req.user.role !== 'student';
  if (!isStaff && String(req.user._id) !== req.params.id) return res.status(403).json({ message: 'Not allowed.' });
  const u = await User.findById(req.params.id);
  if (!u?.idCard?.filename) return res.status(404).json({ message: 'No ID card uploaded.' });
  res.type(u.idCard.mimetype).sendFile(path.join(upload.root, 'idcards', path.basename(u.idCard.filename)));
});

module.exports = router;
