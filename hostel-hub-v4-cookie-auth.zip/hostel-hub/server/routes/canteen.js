const router = require('express').Router();
const { FoodItem, Order } = require('../models/Canteen');
const { protect, staff, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const notify = require('../utils/notify');
const crypto = require('crypto');

// Demo payment gateway: checks the details look valid and returns a transaction id. No real money moves.
function takePayment(method, d = {}) {
  if (method === 'cod') return { method, status: 'pending' };
  if (method === 'upi') {
    const upi = String(d.upiId || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{2,256}@[a-z]{2,64}$/.test(upi)) throw new Error('Enter a valid UPI ID, e.g. name@okaxis');
    return { method, status: 'paid', ref: upi, txnId: 'UPI' + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString('hex').toUpperCase(), paidAt: new Date() };
  }
  if (method === 'card') {
    const last4 = String(d.last4 || '');
    if (!/^\d{4}$/.test(last4)) throw new Error('Card details are incomplete.');
    return { method, status: 'paid', ref: `Card •••• ${last4}`, txnId: 'CRD' + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString('hex').toUpperCase(), paidAt: new Date() };
  }
  throw new Error('Choose a payment method.');
}

router.use(protect);

// ---- menu items ----
router.get('/items', async (req, res) => res.json(await FoodItem.find().sort({ category: 1, name: 1 })));

router.post('/items', staff, upload.food.single('image'), async (req, res) => {
  const { name, price, category, description, imageUrl } = req.body;
  if (!name || price === undefined || Number(price) < 0) {
    if (req.file) upload.remove('food', req.file.filename);
    return res.status(400).json({ message: 'Name and a valid price are required.' });
  }
  const url = /^https?:\/\//.test(imageUrl || '') ? imageUrl.trim() : undefined;
  const item = await FoodItem.create({ name, price: Number(price), category, description, image: req.file?.filename || url });
  notify(req, 'canteen');
  res.status(201).json(item);
});

router.patch('/items/:id', staff, async (req, res) => {
  const patch = {};
  if (typeof req.body.available === 'boolean') patch.available = req.body.available;
  if (req.body.price !== undefined) patch.price = Number(req.body.price);
  const item = await FoodItem.findByIdAndUpdate(req.params.id, patch, { new: true });
  notify(req, 'canteen');
  res.json(item);
});

// Staff replace an item's photo (multer upload)
router.put('/items/:id/image', staff, upload.food.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Choose an image.' });
  const item = await FoodItem.findById(req.params.id);
  if (!item) { upload.remove('food', req.file.filename); return res.status(404).json({ message: 'Item not found.' }); }
  if (item.image && !/^https?:/.test(item.image)) upload.remove('food', item.image);
  item.image = req.file.filename;
  await item.save();
  notify(req, 'canteen');
  res.json(item);
});

router.delete('/items/:id', staff, async (req, res) => {
  const item = await FoodItem.findByIdAndDelete(req.params.id);
  if (item?.image && !/^https?:/.test(item.image)) upload.remove('food', item.image);
  notify(req, 'canteen');
  res.json({ message: 'Item removed.' });
});

// ---- orders ----
router.get('/orders', async (req, res) => {
  const filter = req.user.role === 'student' ? { student: req.user._id } : {};
  res.json(await Order.find(filter).populate('student', 'name rollNo phone').sort({ createdAt: -1 }).limit(60));
});

router.post('/orders', authorize('student'), async (req, res) => {
  const lines = Array.isArray(req.body.items) ? req.body.items : [];
  if (!lines.length) return res.status(400).json({ message: 'Your cart is empty.' });
  const foods = await FoodItem.find({ _id: { $in: lines.map((l) => l.foodId) } });
  const items = [];
  for (const l of lines) {
    const food = foods.find((f) => String(f._id) === String(l.foodId));
    const qty = Math.min(Math.max(parseInt(l.qty, 10) || 0, 1), 10);
    if (!food || !food.available) return res.status(400).json({ message: `${food?.name || 'An item'} is not available right now.` });
    items.push({ food: food._id, name: food.name, price: food.price, qty }); // price is always taken from the DB
  }
  let payment;
  try { payment = takePayment(req.body.paymentMethod || 'cod', req.body.payment); }
  catch (e) { return res.status(400).json({ message: e.message }); }
  await req.user.populate('room', 'number block');
  const order = await Order.create({
    student: req.user._id,
    roomLabel: req.user.room ? `${req.user.room.block}-${req.user.room.number}` : 'No room',
    items, note: req.body.note, payment,
    total: items.reduce((s, i) => s + i.price * i.qty, 0)
  });
  notify(req, 'orders');
  res.status(201).json(order);
});

const NEXT = { placed: ['preparing', 'cancelled'], preparing: ['ready', 'cancelled'], ready: ['delivered'] };
router.patch('/orders/:id/status', staff, async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found.' });
  if (!(NEXT[order.status] || []).includes(req.body.status)) return res.status(400).json({ message: `Cannot move from ${order.status} to ${req.body.status}.` });
  order.status = req.body.status;
  if (order.status === 'delivered' && order.payment?.status === 'pending') { order.payment.status = 'paid'; order.payment.paidAt = new Date(); } // cash collected
  if (order.status === 'cancelled' && order.payment?.status === 'paid') order.payment.status = 'refunded';
  await order.save();
  notify(req, 'orders');
  res.json(order);
});

router.patch('/orders/:id/cancel', authorize('student'), async (req, res) => {
  const order = await Order.findOne({ _id: req.params.id, student: req.user._id });
  if (!order) return res.status(404).json({ message: 'Order not found.' });
  if (order.status !== 'placed') return res.status(400).json({ message: 'The canteen has already started this order.' });
  order.status = 'cancelled';
  if (order.payment?.status === 'paid') order.payment.status = 'refunded';
  await order.save();
  notify(req, 'orders');
  res.json(order);
});

module.exports = router;
