const router = require('express').Router();
const { Machine, Booking } = require('../models/Laundry');
const { protect, authorize } = require('../middleware/auth');
const notify = require('../utils/notify');

const SLOT_MINUTES = 45;
router.use(protect);

router.get('/machines', async (req, res) => {
  const machines = await Machine.find().lean();
  const active = await Booking.find({ end: { $gt: new Date() } }).populate('student', 'name rollNo').lean();
  res.json(machines.map((m) => {
    const b = active.find((x) => String(x.machine) === String(m._id));
    return { ...m, booking: b ? { end: b.end, start: b.start, mine: String(b.student._id) === String(req.user._id), student: req.user.role === 'student' ? undefined : b.student } : null };
  }));
});

router.get('/bookings', async (req, res) => {
  const filter = req.user.role === 'student' ? { student: req.user._id } : {};
  res.json(await Booking.find(filter).populate('machine', 'name').populate('student', 'name rollNo').sort({ start: -1 }).limit(40));
});

router.post('/book', authorize('student'), async (req, res) => {
  const now = new Date();
  if (await Booking.exists({ student: req.user._id, end: { $gt: now } }))
    return res.status(400).json({ message: 'You already have a machine booked right now.' });
  if (await Booking.exists({ machine: req.body.machineId, end: { $gt: now } }))
    return res.status(409).json({ message: 'Someone just booked this machine.' });
  const b = await Booking.create({ machine: req.body.machineId, student: req.user._id, start: now, end: new Date(now.getTime() + SLOT_MINUTES * 60000) });
  notify(req, 'laundry');
  res.status(201).json(b);
});

router.post('/machines', authorize('admin'), async (req, res) => {
  if (!req.body.name) return res.status(400).json({ message: 'Machine name required.' });
  const m = await Machine.create({ name: req.body.name });
  notify(req, 'laundry');
  res.status(201).json(m);
});

router.delete('/machines/:id', authorize('admin'), async (req, res) => {
  await Machine.findByIdAndDelete(req.params.id);
  await Booking.deleteMany({ machine: req.params.id });
  notify(req, 'laundry');
  res.json({ message: 'Machine removed.' });
});

module.exports = router;
