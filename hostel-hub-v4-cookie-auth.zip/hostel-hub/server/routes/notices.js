const router = require('express').Router();
const Notice = require('../models/Notice');
const { protect, staff } = require('../middleware/auth');
const upload = require('../middleware/upload');
const notify = require('../utils/notify');

router.use(protect);

router.get('/', async (req, res) => {
  res.json(await Notice.find().populate('by', 'name role').sort({ createdAt: -1 }));
});

// Warden/admin write a notice or circular and optionally attach a file (multer)
router.post('/', staff, upload.notice.single('attachment'), async (req, res) => {
  const { title, desc, category } = req.body;
  if (!title || !desc) {
    if (req.file) upload.remove('notices', req.file.filename);
    return res.status(400).json({ message: 'Title and details are required.' });
  }
  const n = await Notice.create({
    title, desc, category, by: req.user._id,
    ...(req.file && { attachment: { filename: req.file.filename, originalName: req.file.originalname, mimetype: req.file.mimetype } })
  });
  notify(req, 'notices');
  res.status(201).json(n);
});

router.delete('/:id', staff, async (req, res) => {
  const n = await Notice.findById(req.params.id);
  if (!n) return res.status(404).json({ message: 'Notice not found.' });
  if (req.user.role !== 'admin' && String(n.by) !== String(req.user._id)) return res.status(403).json({ message: 'Only the author or an admin can delete this.' });
  upload.remove('notices', n.attachment?.filename);
  await n.deleteOne();
  notify(req, 'notices');
  res.json({ message: 'Notice deleted.' });
});

module.exports = router;
