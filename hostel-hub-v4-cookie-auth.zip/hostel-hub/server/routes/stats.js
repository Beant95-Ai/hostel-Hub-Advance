const router = require('express').Router();
const User = require('../models/User');
const Room = require('../models/Room');
const Complaint = require('../models/Complaint');
const VisitorPass = require('../models/VisitorPass');
const Notice = require('../models/Notice');
const { Order } = require('../models/Canteen');
const { Booking } = require('../models/Laundry');
const { protect } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  if (req.user.role === 'student') {
    const me = req.user._id;
    const [complaints, pending, bookings, orders] = await Promise.all([
      Complaint.countDocuments({ student: me }),
      Complaint.countDocuments({ student: me, status: { $ne: 'resolved' } }),
      Booking.countDocuments({ student: me }),
      Order.countDocuments({ student: me, status: { $in: ['placed', 'preparing', 'ready'] } })
    ]);
    return res.json({ complaints, pending, bookings, orders });
  }
  const [students, rooms, complaints, passes, orders, notices] = await Promise.all([
    User.countDocuments({ role: 'student' }),
    Room.aggregate([{ $group: { _id: null, beds: { $sum: '$capacity' }, used: { $sum: { $size: '$occupants' } } } }]),
    Complaint.countDocuments({ status: { $ne: 'resolved' } }),
    VisitorPass.countDocuments({ status: 'pending' }),
    Order.countDocuments({ status: { $in: ['placed', 'preparing', 'ready'] } }),
    Notice.countDocuments()
  ]);
  res.json({ students, beds: rooms[0]?.beds || 0, used: rooms[0]?.used || 0, complaints, passes, orders, notices });
});

module.exports = router;
