const router = require('express').Router();
const Room = require('../models/Room');
const User = require('../models/User');
const { protect, staff, authorize } = require('../middleware/auth');
const notify = require('../utils/notify');

router.use(protect);

router.get('/', async (req, res) => {
  const q = Room.find().sort({ block: 1, number: 1 });
  // roommates' names are visible to staff, and to students only for their own room
  const rooms = await q.populate('occupants', 'name rollNo phone course').lean();
  const mine = String(req.user.room || '');
  res.json(rooms.map((r) => {
    const visible = req.user.role !== 'student' || String(r._id) === mine;
    return { ...r, occupants: visible ? r.occupants : r.occupants.map(() => ({})), occupied: r.occupants.length };
  }));
});

router.post('/', staff, async (req, res) => {
  const { number, block, floor, type, capacity } = req.body;
  if (!number || !block) return res.status(400).json({ message: 'Room number and block are required.' });
  if (await Room.exists({ number: String(number).trim() })) return res.status(409).json({ message: 'Room already exists.' });
  const room = await Room.create({ number, block, floor, type, capacity });
  notify(req, 'rooms');
  res.status(201).json(room);
});

router.delete('/:id', authorize('admin'), async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) return res.status(404).json({ message: 'Room not found.' });
  if (room.occupants.length) return res.status(400).json({ message: 'Vacate the room before deleting it.' });
  await room.deleteOne();
  notify(req, 'rooms');
  res.json({ message: 'Room deleted.' });
});

// Allot: a student picks a room for themselves, or staff allots any student.
router.post('/:id/allot', async (req, res) => {
  const studentId = req.user.role === 'student' ? req.user._id : req.body.studentId;
  const student = await User.findOne({ _id: studentId, role: 'student' });
  if (!student) return res.status(404).json({ message: 'Student not found.' });
  if (String(student.room) === req.params.id) return res.status(400).json({ message: 'Already in this room.' });

  // Atomic capacity check: the update only matches while a bed is still free
  const room = await Room.findOneAndUpdate(
    { _id: req.params.id, occupants: { $ne: student._id }, $expr: { $lt: [{ $size: '$occupants' }, '$capacity'] } },
    { $addToSet: { occupants: student._id } },
    { new: true }
  );
  if (!room) return res.status(409).json({ message: 'This room is full (or no longer exists).' });

  if (student.room) await Room.updateOne({ _id: student.room }, { $pull: { occupants: student._id } });
  student.room = room._id;
  await student.save();
  notify(req, 'rooms'); notify(req, 'users');
  res.json({ message: `Room ${room.number} allotted.` });
});

router.post('/vacate', async (req, res) => {
  const studentId = req.user.role === 'student' ? req.user._id : req.body.studentId;
  const student = await User.findById(studentId);
  if (!student?.room) return res.status(400).json({ message: 'No room allotted.' });
  await Room.updateOne({ _id: student.room }, { $pull: { occupants: student._id } });
  student.room = null;
  await student.save();
  notify(req, 'rooms'); notify(req, 'users');
  res.json({ message: 'Room vacated.' });
});

module.exports = router;
