const router = require('express').Router();
const { MessMenu } = require('../models/Canteen');
const { protect, staff } = require('../middleware/auth');
const notify = require('../utils/notify');

const ORDER = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
router.use(protect);

router.get('/', async (req, res) => {
  const menu = await MessMenu.find().lean();
  res.json(menu.sort((a, b) => ORDER.indexOf(a.day) - ORDER.indexOf(b.day)));
});

router.put('/:day', staff, async (req, res) => {
  const { breakfast, lunch, dinner } = req.body;
  const m = await MessMenu.findOneAndUpdate({ day: req.params.day }, { breakfast, lunch, dinner }, { new: true, upsert: true });
  notify(req, 'mess');
  res.json(m);
});

module.exports = router;
