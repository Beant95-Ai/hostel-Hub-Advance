const router = require('express').Router();
const Complaint = require('../models/Complaint');
const { protect, staff, authorize } = require('../middleware/auth');
const notify = require('../utils/notify');

router.use(protect);

router.get('/', async (req, res) => {
  const filter = req.user.role === 'student' ? { student: req.user._id } : {};
  res.json(await Complaint.find(filter).populate({ path: 'student', select: 'name rollNo room', populate: { path: 'room', select: 'number block' } }).sort({ createdAt: -1 }));
});

router.post('/', authorize('student'), async (req, res) => {
  const { title, desc, category } = req.body;
  if (!title || !desc) return res.status(400).json({ message: 'Title and details are required.' });
  const c = await Complaint.create({ student: req.user._id, title, desc, category });
  notify(req, 'complaints');
  res.status(201).json(c);
});

router.patch('/:id', staff, async (req, res) => {
  if (!['pending', 'in-progress', 'resolved'].includes(req.body.status)) return res.status(400).json({ message: 'Invalid status.' });
  const c = await Complaint.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!c) return res.status(404).json({ message: 'Complaint not found.' });
  notify(req, 'complaints');
  res.json(c);
});

module.exports = router;
