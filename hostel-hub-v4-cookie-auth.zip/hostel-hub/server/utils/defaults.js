// Runs every time the server starts (and from `npm run seed`).
// Only creates what is missing, so it never overwrites your data.
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Room = require('../models/Room');
const { Machine } = require('../models/Laundry');
const Notice = require('../models/Notice');
const { MessMenu, FoodItem } = require('../models/Canteen');

// Food photos (Wikimedia Commons, free to use). Staff can replace any of them by uploading a photo.
const pic = (file) => `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(file)}?width=600`;

const STAFF = [
  { rollNo: 'WARDEN01', name: 'R. Sharma', role: 'warden', password: 'warden123', phone: '9876500000' },
  { rollNo: 'ADMIN01', name: 'System Admin', role: 'admin', password: 'admin123', phone: '9876500001' }
];

const FOODS = [
  { name: 'Aloo Paratha', description: 'With curd and pickle', category: 'Meals', price: 40, image: pic('Aloo Paratha with curd and Pickle.jpg') },
  { name: 'Veg Sandwich', description: 'Grilled, with chutney', category: 'Snacks', price: 35, image: pic('Veg Sandwich with Sundried Tomatoes and Mushrooms.jpg') },
  { name: 'Samosa (2 pcs)', description: 'With green chutney', category: 'Snacks', price: 20, image: pic('North Indian style samosa.jpg') },
  { name: 'Maggi', description: 'Masala, extra vegetables', category: 'Snacks', price: 30, image: pic('Desi Maggi.jpg') },
  { name: 'Masala Chai', description: 'Kadak, with ginger', category: 'Beverages', price: 10, image: pic('Masala Chai.JPG') },
  { name: 'Cold Coffee', description: 'Chilled, with chocolate', category: 'Beverages', price: 40, image: pic('Chocolate Cold Coffee.jpg') },
  { name: 'Lassi', description: 'Sweet Punjabi lassi with malai', category: 'Beverages', price: 30, image: pic('Lassi.jpg') },
  { name: 'Gulab Jamun (2 pcs)', description: 'Warm, in sugar syrup', category: 'Desserts', price: 25, image: pic('Gulab jamun 1.jpg') },
  { name: 'Biscuits pack', category: 'Essentials', price: 10, image: pic('Biscuits on a plate, Goa India.JPG') },
  { name: 'Water bottle 1L', category: 'Essentials', price: 20, image: pic('PET Bottle Water.jpg') }
];

const MENU = {
  Mon: ['Poha, Tea', 'Rajma Chawal, Salad', 'Paneer Curry, Roti'],
  Tue: ['Idli Sambhar', 'Chole, Rice', 'Mix Veg, Roti'],
  Wed: ['Bread Omelette / Paratha', 'Dal Fry, Rice', 'Kadhi Chawal'],
  Thu: ['Upma', 'Rajma Chawal', 'Aloo Gobi, Roti'],
  Fri: ['Paratha, Curd', 'Chicken/Soya Curry, Rice', 'Dal Makhani, Roti'],
  Sat: ['Sandwich, Tea', 'Veg Pulao, Raita', 'Special Thali'],
  Sun: ['Chole Bhature', 'Fried Rice', 'Khichdi']
};

module.exports = async function ensureDefaults() {
  // 1. Demo warden + admin accounts (so staff can always log in)
  for (const s of STAFF)
    if (!(await User.exists({ rollNo: s.rollNo }))) await User.create({ ...s, password: await bcrypt.hash(s.password, 10) });

  // 2. Rooms
  if (!(await Room.countDocuments())) {
    const rooms = [];
    for (const block of ['A', 'B'])
      for (let floor = 1; floor <= 3; floor++)
        for (let n = 1; n <= 6; n++)
          rooms.push({ block, floor, number: `${block}${floor}0${n}`, capacity: n % 3 === 0 ? 2 : 3, type: n === 6 ? 'AC' : 'Non-AC' });
    await Room.insertMany(rooms);
  }

  // 3. Laundry machines
  if (!(await Machine.countDocuments())) await Machine.insertMany([1, 2, 3, 4].map((n) => ({ name: `Machine ${n}` })));

  // 4. Mess menu
  if (!(await MessMenu.countDocuments()))
    for (const [day, [breakfast, lunch, dinner]] of Object.entries(MENU))
      await MessMenu.findOneAndUpdate({ day }, { breakfast, lunch, dinner }, { upsert: true });

  // 5. Canteen items — add the defaults, and give a photo to any default item that has none
  if (!(await FoodItem.countDocuments())) await FoodItem.insertMany(FOODS);
  else
    for (const f of FOODS)
      await FoodItem.updateOne({ name: f.name, $or: [{ image: null }, { image: '' }, { image: { $exists: false } }] },
        { $set: { image: f.image, ...(f.description && { description: f.description }) } });

  // 6. A couple of sample notices
  if (!(await Notice.countDocuments())) {
    const w = await User.findOne({ rollNo: 'WARDEN01' });
    await Notice.insertMany([
      { title: 'Mess timing changed', desc: 'Dinner is now served 8:00-9:30 PM starting this week.', category: 'notice', by: w._id },
      { title: 'Fire drill on Friday', desc: 'Mandatory fire drill at 6 PM. Assemble in the courtyard.', category: 'urgent', by: w._id }
    ]);
  }
};
