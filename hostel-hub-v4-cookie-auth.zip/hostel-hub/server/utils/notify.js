// Tells every connected browser that some data changed (Socket.IO).
module.exports = (req, type) => req.app.get('io').emit('update', { type });
