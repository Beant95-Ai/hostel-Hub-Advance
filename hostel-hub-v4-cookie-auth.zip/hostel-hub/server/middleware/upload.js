const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const root = path.join(__dirname, '..', 'uploads');
const IMG = ['image/jpeg', 'image/png', 'image/webp'];
const DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
const EXT = {
  'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp',
  'application/pdf': '.pdf', 'application/msword': '.doc', [DOCX]: '.docx'
};

// Random file names; extension comes from the verified mime type, never from the user.
function make(folder, mimes, maxMB) {
  const dir = path.join(root, folder);
  fs.mkdirSync(dir, { recursive: true });
  return multer({
    storage: multer.diskStorage({
      destination: dir,
      filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + EXT[file.mimetype])
    }),
    limits: { fileSize: maxMB * 1024 * 1024 },
    fileFilter: (req, file, cb) =>
      mimes.includes(file.mimetype) ? cb(null, true) : cb(new Error('This file type is not allowed.'))
  });
}

const remove = (folder, filename) => {
  if (filename) fs.unlink(path.join(root, folder, path.basename(filename)), () => {});
};

module.exports = {
  root,
  remove,
  idCard: make('idcards', [...IMG, 'application/pdf'], 2),
  notice: make('notices', [...IMG, 'application/pdf', 'application/msword', DOCX], 5),
  food: make('food', IMG, 2)
};
