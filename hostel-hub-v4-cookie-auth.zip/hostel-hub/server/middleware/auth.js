// =====================================================================
//  AUTH = JWT stored inside a COOKIE  (same idea as sir's session_g1)
//
//  1. Login  -> signToken(user)   -> creates the JWT
//  2.        -> setAuthCookie()   -> res.cookie("token", jwt)
//  3. Every request -> browser sends the cookie automatically
//  4. verifyToken reads req.cookies.token -> jwt.verify -> req.user
//  5. Logout -> res.clearCookie("token")
// =====================================================================
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const ONE_DAY = 1000 * 60 * 60 * 24;

// 1) create the JWT (user id, role, name, email) – expires in 1 day
exports.signToken = (user) =>
  jwt.sign(
    { id: user._id, role: user.role, name: user.name, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: '1d' }
  );

// 2) put the JWT inside a cookie called "token"
exports.setAuthCookie = (res, token) => {
  res.cookie('token', token, {
    httpOnly: true,      // JavaScript in the browser cannot read it (safer)
    sameSite: 'lax',
    maxAge: ONE_DAY      // cookie lives as long as the JWT
  });
};

// 5) logout -> delete the cookie
exports.clearAuthCookie = (res) => res.clearCookie('token', { httpOnly: true, sameSite: 'lax' });

// 4) middleware: is the user logged in?
exports.verifyToken = (req, res, next) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: 'Please log in first.' });

  jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
    if (err) return res.status(401).json({ message: 'Session expired. Please log in again.' });

    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });

    req.user = user;
    next();
  });
};

// old names still work in all route files
exports.protect = exports.verifyToken;
exports.requireAuth = exports.verifyToken;

// Role check: are you allowed to do this?
exports.authorize = (...roles) => (req, res, next) =>
  roles.includes(req.user.role)
    ? next()
    : res.status(403).json({ message: 'You do not have permission for this action.' });

exports.staff = exports.authorize('warden', 'admin');
