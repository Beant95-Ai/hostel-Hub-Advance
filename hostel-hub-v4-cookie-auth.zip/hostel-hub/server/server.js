require('dotenv').config();
// Safe defaults so the app still runs if .env is missing (e.g. on Windows where `cp` failed)
process.env.MONGO_URI ||= 'mongodb://127.0.0.1:27017/hostel_hub';
process.env.JWT_SECRET ||= 'hostel_hub_dev_secret_change_me';
const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const connectDB = require('./config/db');
const upload = require('./middleware/upload');
const ensureDefaults = require('./utils/defaults');

const app = express();
const server = http.createServer(app);
const CLIENT = process.env.CLIENT_URL || 'http://localhost:5173';

// ---- real-time (Socket.IO, JWT-protected) ----
// The socket also uses the same "token" cookie (browser sends it automatically)
const io = new Server(server, { cors: { origin: CLIENT, credentials: true } });
io.use((socket, next) => {
  const cookies = Object.fromEntries((socket.handshake.headers.cookie || '').split('; ').filter(Boolean)
    .map((c) => [c.slice(0, c.indexOf('=')), decodeURIComponent(c.slice(c.indexOf('=') + 1))]));
  try { socket.user = jwt.verify(cookies.token, process.env.JWT_SECRET); next(); }
  catch { next(new Error('unauthorized')); }
});
app.set('io', io);

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: CLIENT, credentials: true }));   // credentials = allow cookies
app.use(express.json());
app.use(cookieParser());                                 // gives us req.cookies.token
app.use((req, res, next) => { req.body = req.body || {}; next(); });

// Public files: notice attachments and food photos. ID cards are NOT here (see /api/users/:id/idcard).
app.use('/uploads/notices', express.static(path.join(upload.root, 'notices')));
app.use('/uploads/food', express.static(path.join(upload.root, 'food')));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/rooms', require('./routes/rooms'));
app.use('/api/complaints', require('./routes/complaints'));
app.use('/api/laundry', require('./routes/laundry'));
app.use('/api/visitors', require('./routes/visitors'));
app.use('/api/notices', require('./routes/notices'));
app.use('/api/mess', require('./routes/mess'));
app.use('/api/canteen', require('./routes/canteen'));
app.use('/api/stats', require('./routes/stats'));

app.use((req, res) => res.status(404).json({ message: 'Not found.' }));
app.use((err, req, res, next) => {
  if (err.name === 'MulterError') return res.status(400).json({ message: err.code === 'LIMIT_FILE_SIZE' ? 'File is too large.' : err.message });
  if (err.message === 'This file type is not allowed.') return res.status(400).json({ message: err.message });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid id.' });
  console.error(err);
  res.status(500).json({ message: 'Server error. Please try again.' });
});

connectDB()
  .then(ensureDefaults)
  .then(() => server.listen(process.env.PORT || 5000, () => console.log('API running on port', process.env.PORT || 5000)))
  .catch((e) => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
