// Optional (the server already does this on start):  npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const ensureDefaults = require('./utils/defaults');

(async () => {
  await connectDB();
  await ensureDefaults();
  console.log('Seed complete. Warden: WARDEN01 / warden123   Admin: ADMIN01 / admin123');
  await mongoose.disconnect();
  process.exit(0);
})().catch((e) => { console.error('Seed failed:', e.message); process.exit(1); });
