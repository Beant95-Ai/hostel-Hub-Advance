# Hostel Hub (v2) — React + Express + MongoDB

## Run it on Windows (step by step)

### 1. Install once
- **Node.js 20 LTS** – https://nodejs.org (check: `node -v`)
- **MongoDB Community Server** – https://www.mongodb.com/try/download/community
  During setup tick **"Install MongoDB as a Service"** (and MongoDB Compass if you want a GUI).

### 2. Start MongoDB
Open **Command Prompt as Administrator**:
```bat
net start MongoDB
```
(If it says "already started" that's fine.) Check it works:
```bat
mongosh --eval "db.runCommand({ ping: 1 })"
```
Or open MongoDB Compass and connect to `mongodb://127.0.0.1:27017`.

**Using MongoDB Atlas instead?** Open `server\.env` and replace `MONGO_URI` with your Atlas string, e.g.
`MONGO_URI=mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/hostel_hub?retryWrites=true&w=majority`
and in Atlas → Network Access add your IP (or `0.0.0.0/0` for testing).

### 3. Backend (terminal 1)
```bat
cd hostel-hub\server
npm install
npm run dev
```
You should see `MongoDB connected: 127.0.0.1 / hostel_hub` and `API running on port 5000`.
`server\.env` is already included. On first start the server creates the demo warden/admin, rooms,
mess menu and canteen items (with photos) automatically — `npm run seed` is optional.

### 4. Frontend (terminal 2)
```bat
cd hostel-hub\client
npm install
npm run dev
```
Open http://localhost:5173

### Logins
- Warden `WARDEN01 / warden123`, Admin `ADMIN01 / admin123`
- Or **Sign up** → pick Student / Warden / Admin. Wardens and admins only need a staff number (no staff code).

### Common problems
| Error | Fix |
|---|---|
| `connect ECONNREFUSED 127.0.0.1:27017` | MongoDB not running → `net start MongoDB` (as Administrator) |
| `The service name is invalid` | MongoDB wasn't installed as a service → reinstall with that box ticked, or run `"C:\Program Files\MongoDB\Server\8.0\bin\mongod.exe" --dbpath C:\data\db` (create `C:\data\db` first) |
| `querySrv ENOTFOUND` / Atlas timeout | Wrong Atlas URI or your IP not allowed in Network Access |
| Port 5000 busy | Change `PORT` in `server\.env` and `API` in `client\vite.config.js` |

## Make it yours
- University name, logo, campus photos: `client/src/config.js` (put files in `client/public`).

## What is inside
| Need | Where |
|---|---|
| JWT-in-cookie login, bcrypt, role checks | `server/routes/auth.js`, `server/middleware/auth.js` |
| Multer uploads (ID card, notice/circular attachments, food photos) | `server/middleware/upload.js`, `server/routes/notices.js` |
| Private ID cards (owner + staff only) | `GET /api/users/:id/idcard` |
| Room allotment (atomic, capacity-safe) | `server/routes/rooms.js` |
| Canteen orders + demo payment (UPI / card / cash) | `server/routes/canteen.js`, `client/src/pages/Mess.jsx` |
| Default staff, food photos, rooms on first start | `server/utils/defaults.js` |
| Real-time updates (Socket.IO) | `server/utils/notify.js`, `client/src/live.js` |

## How login works (JWT + cookie + localStorage)
| What | What's stored | Where it's created | Where it's used |
|---|---|---|---|
| JWT | user id, role, name, email; expires in 1 day | `signToken()` in `server/middleware/auth.js` | checked by `verifyToken` on every protected API |
| Cookie `token` | the JWT (httpOnly, 1 day) | `setAuthCookie()` at login / signup | sent by the browser automatically (API + Socket.IO); deleted by `POST /api/auth/logout` |
| localStorage `currentUser` | user info only (name, role, room…), **never the token** | `AuthContext.jsx` after login / `/auth/me` | shows user info; cleared at logout or when the cookie expires |

Flow: login → `jwt.sign` → `res.cookie("token")` → `verifyToken` reads `req.cookies.token` → logout `res.clearCookie("token")`.
