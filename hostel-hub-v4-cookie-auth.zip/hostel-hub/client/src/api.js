import axios from 'axios';

// withCredentials: true -> browser sends the "token" cookie with every request
const api = axios.create({ baseURL: '/api', withCredentials: true });

api.interceptors.response.use((r) => r, (err) => {
  // cookie / JWT expired while logged in -> clear localStorage and go back to login
  const url = err.config?.url || '';
  if (err.response?.status === 401 && localStorage.getItem('currentUser') && !url.includes('/auth/')) {
    localStorage.removeItem('currentUser');
    window.location.href = '/';
  }
  return Promise.reject(err);
});

export const errMsg = (e) => e.response?.data?.message || e.message || 'Something went wrong';
export default api;
