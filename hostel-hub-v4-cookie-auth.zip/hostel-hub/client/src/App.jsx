import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import Rooms from './pages/Rooms';
import Complaints from './pages/Complaints';
import Laundry from './pages/Laundry';
import Visitors from './pages/Visitors';
import Notices from './pages/Notices';
import Mess from './pages/Mess';
import Students from './pages/Students';
import Users from './pages/Users';
import Profile from './pages/Profile';

// Role-based route guard (authorization on the client; the API enforces it again)
function Guard({ roles, children }) {
  const { user } = useAuth();
  return !roles || roles.includes(user.role) ? children : <Navigate to="/" replace />;
}

export default function App() {
  const { user, booting } = useAuth();
  if (booting) return <div className="boot">Loading…</div>;
  if (!user) return <Login />;

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="rooms" element={<Rooms />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="laundry" element={<Guard roles={['student', 'admin']}><Laundry /></Guard>} />
        <Route path="visitors" element={<Visitors />} />
        <Route path="notices" element={<Notices />} />
        <Route path="mess" element={<Mess />} />
        <Route path="students" element={<Guard roles={['warden', 'admin']}><Students /></Guard>} />
        <Route path="users" element={<Guard roles={['admin']}><Users /></Guard>} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
