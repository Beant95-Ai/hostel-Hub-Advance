import { createContext, useContext, useEffect, useState } from 'react';
import api from './api';
import { connectSocket, disconnectSocket } from './live';

// ---------------------------------------------------------------
//  JWT    -> lives in the httpOnly cookie "token" (server sets it)
//  localStorage "currentUser" -> only the user's info for showing
//  on screen (name, role...). NO token is kept in localStorage.
// ---------------------------------------------------------------
const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

const saved = () => { try { return JSON.parse(localStorage.getItem('currentUser')); } catch { return null; } };

export function AuthProvider({ children }) {
  const [user, setUserState] = useState(saved);   // show saved user instantly
  const [booting, setBooting] = useState(true);

  const setUser = (u) => {
    if (u) localStorage.setItem('currentUser', JSON.stringify(u));
    else localStorage.removeItem('currentUser');
    setUserState(u);
  };

  const refresh = () => api.get('/auth/me').then((r) => setUser(r.data));

  // On page load: ask the server "is my cookie still valid?"
  useEffect(() => {
    refresh()
      .then(connectSocket)
      .catch(() => setUser(null))          // no / expired cookie -> logged out
      .finally(() => setBooting(false));
  }, []);

  // after login / signup (server already set the cookie)
  const startSession = ({ user }) => {
    setUser(user);
    connectSocket();
  };

  const logout = async () => {
    await api.post('/auth/logout').catch(() => {});   // server deletes the cookie
    disconnectSocket();
    setUser(null);                                     // clears localStorage
  };

  return <Ctx.Provider value={{ user, booting, startSession, logout, refresh }}>{children}</Ctx.Provider>;
}
