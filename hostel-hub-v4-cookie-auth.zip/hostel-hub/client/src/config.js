// ---- Change these to your own university ----
export const UNIVERSITY = {
  name: 'Punjab Institute of Technology',      // <- your university name
  short: 'PIT',
  hostel: 'University Hostel',
  address: 'Rajpura, Punjab',
  logo: '/crest.svg'                             // put your logo in /public and change this, e.g. '/logo.png'
};

// Replace with your own campus photos: save them in client/public/images and use '/images/campus.jpg'
export const PHOTOS = {
  campus: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1800&q=80',
  library: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80',
  room: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80',
  canteen: 'https://images.unsplash.com/photo-1567521464027-f127ff144326?auto=format&fit=crop&w=800&q=80',
  laundry: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=1200&q=80',
  laundryMachines: [
    'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?auto=format&fit=crop&w=700&q=80',
    'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=700&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=700&q=80'
  ]
};
