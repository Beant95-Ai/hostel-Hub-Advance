import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Home, BedDouble, Wrench, Shirt, IdCard, Megaphone, UtensilsCrossed, GraduationCap, Users, UserRound, LogOut, Menu } from 'lucide-react';
import { useAuth } from '../AuthContext';
import { UNIVERSITY } from '../config';

const NAV = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/rooms', label: 'Rooms', icon: BedDouble },
  { to: '/complaints', label: 'Complaints', icon: Wrench },
  { to: '/laundry', label: 'Laundry', icon: Shirt, roles: ['student', 'admin'] },
  { to: '/visitors', label: 'Visitor passes', icon: IdCard },
  { to: '/notices', label: 'Notices & circulars', icon: Megaphone },
  { to: '/mess', label: 'Mess & canteen', icon: UtensilsCrossed },
  { to: '/students', label: 'Students', icon: GraduationCap, roles: ['warden', 'admin'] },
  { to: '/users', label: 'Manage staff', icon: Users, roles: ['admin'] },
  { to: '/profile', label: 'Profile', icon: UserRound }
];

export default function Layout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  useLocation(); // close drawer on navigation handled via onClick below

  return (
    <div className="app">
      <header className="topbar">
        <button className="icon-btn" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={22} /></button>
        <img src={UNIVERSITY.logo} alt="" height="28" />
        <b>Hostel Hub</b>
      </header>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}

      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sb-brand">
          <img src={UNIVERSITY.logo} alt="" height="40" />
          <div>
            <div className="sb-uni">{UNIVERSITY.name}</div>
            <div className="sb-sub">{UNIVERSITY.hostel}</div>
          </div>
        </div>

        <nav className="sb-nav">
          {NAV.filter((n) => !n.roles || n.roles.includes(user.role)).map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)} className={({ isActive }) => 'sb-link' + (isActive ? ' active' : '')}>
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="sb-foot">
          <div className="sb-user">
            <div className="avatar">{user.name[0].toUpperCase()}</div>
            <div>
              <div className="sb-user-name">{user.name}</div>
              <div className="sb-user-roll">{user.rollNo} · {user.role}</div>
            </div>
          </div>
          <button className="btn ghost light" onClick={logout}><LogOut size={16} /> Log out</button>
        </div>
      </aside>

      <main className="main"><Outlet /></main>
    </div>
  );
}
