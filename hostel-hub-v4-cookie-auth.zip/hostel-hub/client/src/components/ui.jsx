import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import api from '../api';

export const fmtDate = (iso) => {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' +
    d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
};
export const money = (n) => '₹' + Number(n).toLocaleString('en-IN');

export const Badge = ({ status }) => <span className={`badge ${status}`}>{status}</span>;

export const Empty = ({ children }) => <div className="empty">{children}</div>;

export const Hero = ({ image, title, sub }) => (
  <div className="hero" style={{ backgroundImage: `linear-gradient(100deg, rgba(14,34,64,.92), rgba(14,34,64,.45)), url(${image})` }}>
    <h2>{title}</h2>
    <p>{sub}</p>
  </div>
);

export const PageHead = ({ title, sub, children }) => (
  <div className="page-head">
    <div><h2>{title}</h2>{sub && <div className="page-sub">{sub}</div>}</div>
    {children}
  </div>
);

export function Modal({ title, onClose, children }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={title}>
        <div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        {children}
      </div>
    </div>
  );
}

// ID cards are private: fetch with the JWT and show as a blob.
export function IdCardViewer({ userId, name, onClose }) {
  const [src, setSrc] = useState(null);
  const [type, setType] = useState('');
  const [err, setErr] = useState('');
  useEffect(() => {
    let url;
    api.get(`/users/${userId}/idcard`, { responseType: 'blob' })
      .then((r) => { url = URL.createObjectURL(r.data); setType(r.data.type); setSrc(url); })
      .catch(() => setErr('No ID card uploaded.'));
    return () => url && URL.revokeObjectURL(url);
  }, [userId]);
  return (
    <Modal title={`ID card — ${name}`} onClose={onClose}>
      {err ? <Empty>{err}</Empty> : !src ? <Empty>Loading…</Empty> :
        type === 'application/pdf'
          ? <iframe title="ID card" src={src} className="idframe" />
          : <img src={src} alt="ID card" className="idimg" />}
    </Modal>
  );
}
