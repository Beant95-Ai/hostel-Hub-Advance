import { useState } from 'react';
import { Banknote, Camera, CheckCircle2, CreditCard, Minus, Plus, ShieldCheck, ShoppingBag, Smartphone, Trash2 } from 'lucide-react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Badge, Empty, Hero, Modal, fmtDate, money } from '../components/ui';
import { PHOTOS } from '../config';

export default function Mess() {
  const [tab, setTab] = useState('menu');
  return (
    <>
      <Hero image={PHOTOS.canteen} title="Mess & canteen" sub="The weekly mess menu, and a canteen you can order from without leaving your room." />
      <div className="seg wrap big">
        <button className={tab === 'menu' ? 'active' : ''} onClick={() => setTab('menu')}>Weekly mess menu</button>
        <button className={tab === 'canteen' ? 'active' : ''} onClick={() => setTab('canteen')}>Canteen</button>
      </div>
      {tab === 'menu' ? <MessMenu /> : <Canteen />}
    </>
  );
}

/* ---------------- Weekly menu ---------------- */
function MessMenu() {
  const { user } = useAuth();
  const toast = useToast();
  const isStaff = user.role !== 'student';
  const { data } = useData('/mess', ['mess']);
  const [day, setDay] = useState('Mon');
  const today = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date().getDay()];

  const save = async (e) => {
    e.preventDefault();
    try { await api.put(`/mess/${day}`, Object.fromEntries(new FormData(e.target))); toast('Menu updated'); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  const current = data?.find((d) => d.day === day);

  return (
    <>
      {isStaff && (
        <div className="card">
          <h3>Update menu</h3>
          <div className="seg wrap">{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => <button key={d} className={day === d ? 'active' : ''} onClick={() => setDay(d)}>{d}</button>)}</div>
          <form onSubmit={save} key={day + (current?._id || '')} className="row4 top">
            <div className="field"><label>Breakfast</label><input name="breakfast" defaultValue={current?.breakfast} required /></div>
            <div className="field"><label>Lunch</label><input name="lunch" defaultValue={current?.lunch} required /></div>
            <div className="field"><label>Dinner</label><input name="dinner" defaultValue={current?.dinner} required /></div>
            <button className="btn primary">Save {day}</button>
          </form>
        </div>
      )}
      <div className="card flush">
        <div className="scroll">
          <table className="table">
            <thead><tr><th>Day</th><th>Breakfast</th><th>Lunch</th><th>Dinner</th></tr></thead>
            <tbody>
              {(data || []).map((d) => (
                <tr key={d.day} className={d.day === today ? 'today' : ''}>
                  <td><b>{d.day}</b>{d.day === today && <span className="chip">today</span>}</td><td>{d.breakfast}</td><td>{d.lunch}</td><td>{d.dinner}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------------- Canteen ---------------- */
const CATS = ['All', 'Snacks', 'Meals', 'Beverages', 'Desserts', 'Essentials'];
const FLOW = { placed: ['preparing', 'cancelled'], preparing: ['ready', 'cancelled'], ready: ['delivered'] };
// An item photo is either an uploaded file or a full https:// URL
const foodSrc = (img) => (!img ? null : /^https?:/.test(img) ? img : `/uploads/food/${img}`);
const PAY = [
  { id: 'upi', label: 'UPI', sub: 'GPay, PhonePe, Paytm', Icon: Smartphone },
  { id: 'card', label: 'Card', sub: 'Debit / credit', Icon: CreditCard },
  { id: 'cod', label: 'Cash', sub: 'Pay on delivery', Icon: Banknote }
];
const PAY_LABEL = { upi: 'UPI', card: 'Card', cod: 'Cash on delivery' };

function Canteen() {
  const { user } = useAuth();
  const isStaff = user.role !== 'student';
  const { data: items, reload: reloadItems } = useData('/canteen/items', ['canteen']);
  const { data: orders } = useData('/canteen/orders', ['orders']);
  const toast = useToast();
  const [cat, setCat] = useState('All');
  const [cart, setCart] = useState({});     // { foodId: qty }
  const [note, setNote] = useState('');
  const [payMethod, setPayMethod] = useState('upi');
  const [paying, setPaying] = useState(false);
  const [receipt, setReceipt] = useState(null);

  const list = (items || []).filter((i) => cat === 'All' || i.category === cat);
  const lines = Object.entries(cart).map(([id, qty]) => ({ item: items?.find((i) => i._id === id), qty })).filter((l) => l.item);
  const total = lines.reduce((s, l) => s + l.item.price * l.qty, 0);
  const setQty = (id, d) => setCart((c) => { const q = (c[id] || 0) + d; const n = { ...c }; q <= 0 ? delete n[id] : (n[id] = Math.min(q, 10)); return n; });

  // payment = { upiId } or { last4 } or {} for cash
  const place = async (payment = {}) => {
    const { data } = await api.post('/canteen/orders', { items: lines.map((l) => ({ foodId: l.item._id, qty: l.qty })), note, paymentMethod: payMethod, payment });
    setCart({}); setNote(''); setPaying(false);
    setReceipt(data);
  };
  const checkout = () => {
    if (payMethod === 'cod') place().catch((e) => toast(errMsg(e), 'err'));
    else setPaying(true);
  };
  const setStatus = (id, status) => api.patch(`/canteen/orders/${id}/status`, { status }).catch((e) => toast(errMsg(e), 'err'));
  const cancel = (id) => api.patch(`/canteen/orders/${id}/cancel`).then(() => toast('Order cancelled')).catch((e) => toast(errMsg(e), 'err'));

  return (
    <div className={isStaff ? '' : 'shop'}>
      <div>
        {isStaff && <ManageItems onChange={reloadItems} items={items} />}
        <div className="seg wrap">{CATS.map((c) => <button key={c} className={cat === c ? 'active' : ''} onClick={() => setCat(c)}>{c}</button>)}</div>

        {!items ? <Empty>Loading…</Empty> : !list.length ? <Empty>No items in this category.</Empty> : (
          <div className="food-grid">
            {list.map((i) => (
              <div className={`food ${i.available ? '' : 'off'}`} key={i._id}>
                <div className="food-img">
                  <span>{i.name[0]}</span>
                  {i.image && <img src={foodSrc(i.image)} alt={i.name} loading="lazy" onError={(e) => (e.currentTarget.style.display = 'none')} />}
                  <span className="food-cat">{i.category}</span>
                  {isStaff && <ChangePhoto id={i._id} />}
                </div>
                <div className="food-body">
                  <b>{i.name}</b>
                  {i.description && <div className="li-meta">{i.description}</div>}
                  <div className="food-row">
                    <span className="price">{money(i.price)}</span>
                    {isStaff ? (
                      <button className="btn small ghost" onClick={() => api.patch(`/canteen/items/${i._id}`, { available: !i.available })}>{i.available ? 'Mark sold out' : 'Mark available'}</button>
                    ) : !i.available ? <span className="li-meta">Sold out</span>
                      : cart[i._id] ? (
                        <div className="qty"><button onClick={() => setQty(i._id, -1)} aria-label="Less"><Minus size={14} /></button>{cart[i._id]}<button onClick={() => setQty(i._id, 1)} aria-label="More"><Plus size={14} /></button></div>
                      ) : <button className="btn small" onClick={() => setQty(i._id, 1)}>Add</button>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {!isStaff && (
        <aside className="cart card">
          <h3><ShoppingBag size={18} /> Your cart</h3>
          {!lines.length ? <Empty>Add something tasty.</Empty> : (
            <>
              {lines.map((l) => (
                <div className="cart-line" key={l.item._id}>
                  <span>{l.item.name} <i>× {l.qty}</i></span><span>{money(l.item.price * l.qty)}</span>
                </div>
              ))}
              <textarea placeholder="Note for the canteen (optional)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} />
              <div className="cart-total"><span>Total</span><b>{money(total)}</b></div>
              <div className="pay-title">Payment method</div>
              <div className="pay-options">
                {PAY.map(({ id, label, sub, Icon }) => (
                  <button type="button" key={id} className={`pay-opt ${payMethod === id ? 'active' : ''}`} onClick={() => setPayMethod(id)}>
                    <Icon size={18} /><b>{label}</b><small>{sub}</small>
                  </button>
                ))}
              </div>
              <div className="li-meta">Delivered to your room{user.room ? ` (${user.room.block}-${user.room.number})` : ''}.</div>
              <button className="btn primary block" onClick={checkout}>{payMethod === 'cod' ? 'Place order' : `Pay ${money(total)}`}</button>
            </>
          )}
        </aside>
      )}

      <div className="card full">
        <h3>{isStaff ? 'Order queue' : 'Your orders'}</h3>
        {!orders ? <Empty>Loading…</Empty> : !orders.length ? <Empty>No orders yet.</Empty> : orders.map((o) => (
          <div className="list-item" key={o._id}>
            <div className="li-main">
              <div className="li-title">{o.items.map((i) => `${i.name} × ${i.qty}`).join(', ')}</div>
              <div className="li-desc">{money(o.total)}{o.note && ` · “${o.note}”`}</div>
              <div className="li-meta pay-line">
                <span className={`paytag ${o.payment?.status || 'pending'}`}>{o.payment?.status === 'paid' ? 'Paid' : o.payment?.status === 'refunded' ? 'Refunded' : 'Payment due'}</span>
                {PAY_LABEL[o.payment?.method || 'cod']}{o.payment?.ref && ` · ${o.payment.ref}`}{o.payment?.txnId && ` · Txn ${o.payment.txnId}`}
              </div>
              <div className="li-meta">{isStaff && `${o.student?.name} (${o.student?.rollNo}) · ${o.roomLabel} · `}{fmtDate(o.createdAt)}</div>
            </div>
            <div className="li-side">
              <Badge status={o.status} />
              {isStaff && (FLOW[o.status] || []).map((n) => <button key={n} className={`btn small ${n === 'cancelled' ? 'ghost' : ''}`} onClick={() => setStatus(o._id, n)}>{n === 'cancelled' ? 'Cancel' : `Mark ${n}`}</button>)}
              {!isStaff && o.status === 'placed' && <button className="btn small ghost" onClick={() => cancel(o._id)}>Cancel</button>}
            </div>
          </div>
        ))}
      </div>

      {paying && <PayModal method={payMethod} amount={total} onClose={() => setPaying(false)} onPay={place} />}
      {receipt && (
        <Modal title="Order placed" onClose={() => setReceipt(null)}>
          <div className="receipt">
            <CheckCircle2 size={44} />
            <h4>{receipt.payment?.status === 'paid' ? `Payment of ${money(receipt.total)} successful` : `Pay ${money(receipt.total)} in cash on delivery`}</h4>
            <p className="li-meta">{receipt.items.map((i) => `${i.name} × ${i.qty}`).join(', ')}</p>
            {receipt.payment?.txnId && <p>Transaction ID <code>{receipt.payment.txnId}</code><br /><span className="li-meta">{receipt.payment.ref}</span></p>}
            <button className="btn primary" onClick={() => setReceipt(null)}>Done</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ---------- Demo payment screen (UPI / Card). No real money is charged. ---------- */
function PayModal({ method, amount, onClose, onPay }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [card, setCard] = useState({ number: '', exp: '', cvv: '', name: '' });
  const [upiId, setUpiId] = useState('');
  const fmtCard = (v) => v.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 ');
  const fmtExp = (v) => v.replace(/\D/g, '').slice(0, 4).replace(/^(\d{2})(\d)/, '$1/$2');

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    let payment;
    if (method === 'upi') {
      if (!/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(upiId.trim())) return setErr('Enter a valid UPI ID, e.g. name@okaxis');
      payment = { upiId: upiId.trim() };
    } else {
      const num = card.number.replace(/\s/g, '');
      const [mm, yy] = card.exp.split('/').map(Number);
      const now = new Date(); const cy = now.getFullYear() % 100;
      if (num.length !== 16) return setErr('Card number must be 16 digits.');
      if (!mm || mm > 12 || !yy || yy < cy || (yy === cy && mm < now.getMonth() + 1)) return setErr('Enter a valid expiry (MM/YY).');
      if (!/^\d{3}$/.test(card.cvv)) return setErr('CVV must be 3 digits.');
      if (!card.name.trim()) return setErr('Enter the name on the card.');
      payment = { last4: num.slice(-4) }; // only the last 4 digits ever leave the browser
    }
    setBusy(true);
    await new Promise((r) => setTimeout(r, 1200)); // "processing"
    try { await onPay(payment); } catch (e2) { setErr(errMsg(e2)); setBusy(false); }
  };

  return (
    <Modal title={method === 'upi' ? 'Pay with UPI' : 'Pay with card'} onClose={busy ? () => {} : onClose}>
      <form onSubmit={submit} className="paybox">
        <div className="pay-amount"><span>Amount</span><b>{money(amount)}</b></div>
        {method === 'upi' ? (
          <>
            <div className="upi-apps">{['GPay', 'PhonePe', 'Paytm', 'BHIM'].map((a) => <span key={a}>{a}</span>)}</div>
            <div className="field"><label>Your UPI ID</label><input value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="yourname@okaxis" autoFocus /></div>
          </>
        ) : (
          <>
            <div className="field"><label>Card number</label><input inputMode="numeric" value={card.number} onChange={(e) => setCard({ ...card, number: fmtCard(e.target.value) })} placeholder="4111 1111 1111 1111" autoFocus /></div>
            <div className="row">
              <div className="field"><label>Expiry</label><input inputMode="numeric" value={card.exp} onChange={(e) => setCard({ ...card, exp: fmtExp(e.target.value) })} placeholder="MM/YY" /></div>
              <div className="field"><label>CVV</label><input inputMode="numeric" type="password" maxLength={3} value={card.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, '') })} placeholder="123" /></div>
            </div>
            <div className="field"><label>Name on card</label><input value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} /></div>
          </>
        )}
        <button className="btn primary block" disabled={busy}>{busy ? 'Processing payment…' : `Pay ${money(amount)}`}</button>
        {err && <div className="msg err">{err}</div>}
        <div className="secure"><ShieldCheck size={15} /> Demo payment for the project — no real money is charged.</div>
      </form>
    </Modal>
  );
}

/* Staff: replace an item's photo (multer upload) */
function ChangePhoto({ id }) {
  const toast = useToast();
  const pick = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const body = new FormData(); body.set('image', f);
    try { await api.put(`/canteen/items/${id}/image`, body); toast('Photo updated'); }
    catch (err) { toast(errMsg(err), 'err'); }
    e.target.value = '';
  };
  return (
    <label className="food-photo-btn" title="Change photo"><Camera size={14} />
      <input type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={pick} /></label>
  );
}

function ManageItems({ onChange, items }) {
  const toast = useToast();
  const [file, setFile] = useState(null);
  const add = async (e) => {
    e.preventDefault();
    const body = new FormData(e.target);
    if (file) body.set('image', file); else body.delete('image');
    try { await api.post('/canteen/items', body); toast('Item added'); e.target.reset(); setFile(null); onChange(); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  return (
    <div className="card">
      <h3>Add a canteen item</h3>
      <form onSubmit={add}>
        <div className="row4">
          <div className="field"><label>Name</label><input name="name" required /></div>
          <div className="field"><label>Price (₹)</label><input name="price" type="number" min="0" required /></div>
          <div className="field"><label>Category</label><select name="category">{CATS.slice(1).map((c) => <option key={c}>{c}</option>)}</select></div>
          <div className="field"><label>Photo</label><label className="drop small">{file ? file.name : 'Choose image'}<input type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={(e) => setFile(e.target.files[0] || null)} /></label></div>
        </div>
        <div className="row">
          <div className="field"><label>Description</label><input name="description" /></div>
          <div className="field"><label>…or photo link <span className="opt">(https://…)</span></label><input name="imageUrl" type="url" placeholder="https://" /></div>
        </div>
        <button className="btn primary">Add item</button>
      </form>
      {items?.length > 0 && (
        <details className="rm"><summary>Remove an item</summary>
          {items.map((i) => <div className="occ" key={i._id}><span>{i.name}</span><button className="icon-btn" aria-label={`Remove ${i.name}`} onClick={() => api.delete(`/canteen/items/${i._id}`).then(onChange)}><Trash2 size={14} /></button></div>)}
        </details>
      )}
    </div>
  );
}
