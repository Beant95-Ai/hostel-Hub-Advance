import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Badge, Empty, Hero, fmtDate } from '../components/ui';
import { PHOTOS } from '../config';

export default function Visitors() {
  const { user } = useAuth();
  const toast = useToast();
  const isStaff = user.role !== 'student';
  const { data, reload } = useData('/visitors', ['visitors']);

  const submit = async (e) => {
    e.preventDefault();
    try { await api.post('/visitors', Object.fromEntries(new FormData(e.target))); toast('Request sent to the warden'); e.target.reset(); reload(); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  const decide = (id, status) => api.patch(`/visitors/${id}`, { status }).then(() => toast(`Pass ${status}`)).catch((e) => toast(errMsg(e), 'err'));

  return (
    <>
      <Hero image={PHOTOS.campus} title={isStaff ? 'Visitor gate desk' : 'Visitor pass'} sub={isStaff ? 'Approve or reject every visitor before entry.' : 'Request entry for a guest and track the decision.'} />

      {!isStaff && (
        <div className="card">
          <h3>New visitor request</h3>
          <form onSubmit={submit}>
            <div className="row">
              <div className="field"><label>Visitor name</label><input name="visitorName" required /></div>
              <div className="field"><label>Visitor phone</label><input name="visitorPhone" inputMode="numeric" required /></div>
            </div>
            <div className="row">
              <div className="field"><label>Visit date</label><input type="date" name="visitDate" min={new Date().toISOString().slice(0, 10)} required /></div>
              <div className="field"><label>Purpose</label><input name="purpose" required placeholder="e.g. Parent visit" /></div>
            </div>
            <button className="btn primary">Send request</button>
          </form>
        </div>
      )}

      <div className="card">
        <h3>{isStaff ? 'All requests' : 'Your requests'}</h3>
        {!data ? <Empty>Loading…</Empty> : !data.length ? <Empty>No visitor requests.</Empty> : data.map((p) => (
          <div className="list-item" key={p._id}>
            <div className="li-main">
              <div className="li-title">{p.visitorName}{isStaff && <span className="dim"> visiting {p.student?.name} ({p.student?.rollNo})</span>}</div>
              <div className="li-desc">{p.purpose} · {p.visitorPhone} · on {p.visitDate}</div>
              <div className="li-meta">Requested {fmtDate(p.createdAt)}</div>
            </div>
            <div className="li-side">
              <Badge status={p.status} />
              {isStaff && p.status === 'pending' && <>
                <button className="btn small" onClick={() => decide(p._id, 'approved')}>Approve</button>
                <button className="btn small ghost" onClick={() => decide(p._id, 'rejected')}>Reject</button>
              </>}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
