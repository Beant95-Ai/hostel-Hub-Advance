import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Badge, Empty, PageHead } from '../components/ui';

export default function Users() {
  const { user } = useAuth();
  const toast = useToast();
  const { data, reload } = useData('/users', ['users']);

  const create = async (e) => {
    e.preventDefault();
    try { await api.post('/users', Object.fromEntries(new FormData(e.target))); toast('Account created'); e.target.reset(); reload(); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  const remove = (u) => window.confirm(`Remove ${u.name}? This cannot be undone.`) &&
    api.delete(`/users/${u._id}`).then(() => toast('User removed')).catch((e) => toast(errMsg(e), 'err'));

  return (
    <>
      <PageHead title="Manage accounts" sub={data ? `${data.length} total accounts` : ''} />
      <div className="card">
        <h3>Create a warden or admin</h3>
        <form onSubmit={create} className="row4">
          <div className="field"><label>Name</label><input name="name" required /></div>
          <div className="field"><label>Staff number</label><input name="rollNo" required /></div>
          <div className="field"><label>Password</label><input name="password" type="password" minLength={6} required /></div>
          <div className="field"><label>Role</label><select name="role"><option value="warden">warden</option><option value="admin">admin</option></select></div>
          <button className="btn primary">Create</button>
        </form>
      </div>
      <div className="card">
        {!data ? <Empty>Loading…</Empty> : data.map((u) => (
          <div className="list-item" key={u._id}>
            <div className="li-main"><div className="li-title">{u.name} <Badge status={u.role} /></div><div className="li-meta">{u.rollNo} · {u.phone || 'no phone'}</div></div>
            {u._id !== user._id && <button className="btn small ghost" onClick={() => remove(u)}>Remove</button>}
          </div>
        ))}
      </div>
    </>
  );
}
