import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { Badge, PageHead, fmtDate } from '../components/ui';

const FALLBACK = [
  ['Discipline is choosing between what you want now and what you want most.', 'Unknown'],
  ['Small daily improvements are the key to staggering long-term results.', 'Unknown'],
  ['A room well kept is a mind well kept.', 'Hostel Hub']
];

function Quote() {
  const [q, setQ] = useState(null);
  useEffect(() => {
    fetch('https://api.quotable.io/random?tags=motivational|inspirational')
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => setQ([d.content, d.author]))
      .catch(() => setQ(FALLBACK[Math.floor(Math.random() * FALLBACK.length)]));
  }, []);
  if (!q) return null;
  return <blockquote className="quote">“{q[0]}”<cite>— {q[1]}</cite></blockquote>;
}

export default function Home() {
  const { user } = useAuth();
  const staff = user.role !== 'student';
  const { data: s } = useData('/stats', ['complaints', 'laundry', 'orders', 'users', 'rooms', 'visitors', 'notices']);
  const { data: notices } = useData('/notices', ['notices']);

  const cards = !s ? [] : staff
    ? [['Students registered', s.students], ['Beds occupied', `${s.used} / ${s.beds}`], ['Open complaints', s.complaints], ['Visitor passes waiting', s.passes], ['Canteen orders active', s.orders]]
    : [['Your complaints', s.complaints], ['Still open', s.pending], ['Laundry bookings', s.bookings], ['Canteen orders active', s.orders]];

  return (
    <>
      <PageHead title={`Welcome, ${user.name.split(' ')[0]}`}
        sub={user.role === 'student' ? (user.room ? `Block ${user.room.block} · Room ${user.room.number}` : 'No room allotted yet') : `${user.role} · ${user.rollNo}`} />

      {user.role === 'student' && !user.room && (
        <div className="callout">You have not chosen a room yet. <Link to="/rooms">Pick a room</Link></div>
      )}
      {user.role === 'student' && !user.idCard?.filename && (
        <div className="callout">Your university ID card is missing. <Link to="/profile">Upload it</Link></div>
      )}

      <Quote />

      <div className="stats">
        {cards.map(([label, value]) => (
          <div className="stat" key={label}><div className="stat-num">{value}</div><div className="stat-label">{label}</div></div>
        ))}
      </div>

      <div className="card">
        <div className="card-head"><h3>Latest notices</h3><Link to="/notices">See all</Link></div>
        {!notices ? <div className="empty">Loading…</div> : notices.slice(0, 3).map((n) => (
          <div className="list-item" key={n._id}>
            <div className="li-main"><div className="li-title">{n.title}</div><div className="li-meta">{n.by?.name} · {fmtDate(n.createdAt)}</div></div>
            <Badge status={n.category} />
          </div>
        ))}
      </div>
    </>
  );
}
