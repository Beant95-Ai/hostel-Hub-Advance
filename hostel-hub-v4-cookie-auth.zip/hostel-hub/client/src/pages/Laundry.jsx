import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Empty, Hero, fmtDate } from '../components/ui';
import { PHOTOS } from '../config';

export default function Laundry() {
  const { user } = useAuth();
  const toast = useToast();
  const { data: machines, reload } = useData('/laundry/machines', ['laundry']);
  const { data: bookings } = useData('/laundry/bookings', ['laundry']);
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => { tick((n) => n + 1); reload(); }, 20000); return () => clearInterval(t); }, [reload]);

  const run = (fn, ok) => fn().then(() => toast(ok)).catch((e) => toast(errMsg(e), 'err'));
  const minsLeft = (end) => Math.max(1, Math.round((new Date(end) - new Date()) / 60000));

  return (
    <>
      <Hero image={PHOTOS.laundry} title="Laundry studio" sub="Live machine status. A booking holds a machine for 45 minutes." />

      {user.role === 'admin' && (
        <div className="card">
          <h3>Add a machine</h3>
          <form className="inline" onSubmit={(e) => { e.preventDefault(); const name = e.target.name.value; run(() => api.post('/laundry/machines', { name }), 'Machine added'); e.target.reset(); }}>
            <input name="name" placeholder="e.g. Machine 5" required /><button className="btn primary">Add</button>
          </form>
        </div>
      )}

      <div className="card">
        <h3>Machine floor</h3>
        {!machines ? <Empty>Loading…</Empty> : (
          <div className="machine-grid">
            {machines.map((m, i) => (
              <div className={`machine ${m.booking ? 'busy' : 'free'}`} key={m._id}>
                <div className="machine-img" style={{ backgroundImage: `url(${PHOTOS.laundryMachines[i % PHOTOS.laundryMachines.length]})` }} />
                <div className="machine-body">
                  <b>{m.name}</b>
                  <div className="li-meta">
                    {m.booking ? `${m.booking.mine ? 'Yours' : m.booking.student?.name || 'Booked'} · free in ~${minsLeft(m.booking.end)} min` : 'Ready to use'}
                  </div>
                  {user.role === 'student' && <button className="btn small" disabled={!!m.booking} onClick={() => run(() => api.post('/laundry/book', { machineId: m._id }), 'Machine booked')}>{m.booking ? 'Booked' : 'Book 45 min'}</button>}
                  {user.role === 'admin' && <button className="btn small ghost" onClick={() => run(() => api.delete(`/laundry/machines/${m._id}`), 'Machine removed')}>Remove</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <h3>{user.role === 'admin' ? 'Recent bookings' : 'Your bookings'}</h3>
        {!bookings?.length ? <Empty>No bookings yet.</Empty> : bookings.map((b) => (
          <div className="list-item" key={b._id}>
            <div className="li-main"><div className="li-title">{b.machine?.name || 'Removed machine'}{user.role === 'admin' && ` · ${b.student?.name} (${b.student?.rollNo})`}</div>
              <div className="li-meta">{fmtDate(b.start)} → {fmtDate(b.end)}</div></div>
            <span className={`badge ${new Date(b.end) > new Date() ? 'approved' : 'resolved'}`}>{new Date(b.end) > new Date() ? 'running' : 'done'}</span>
          </div>
        ))}
      </div>
    </>
  );
}
