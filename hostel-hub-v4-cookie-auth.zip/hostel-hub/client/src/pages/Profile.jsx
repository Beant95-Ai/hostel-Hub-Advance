import { useState } from 'react';
import { Eye, Upload } from 'lucide-react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useToast } from '../components/Toast';
import { IdCardViewer, PageHead, fmtDate } from '../components/ui';

export default function Profile() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const [viewing, setViewing] = useState(false);
  const isStudent = user.role === 'student';

  const run = async (fn, ok) => { try { await fn(); toast(ok); await refresh(); } catch (e) { toast(errMsg(e), 'err'); } };

  const saveInfo = (e) => { e.preventDefault(); run(() => api.put('/auth/me', Object.fromEntries(new FormData(e.target))), 'Profile saved'); };
  const savePass = (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    run(() => api.put('/auth/password', f), 'Password updated').then(() => e.target.reset());
  };
  const uploadCard = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const body = new FormData(); body.append('idCard', file);
    run(() => api.post('/users/me/idcard', body), 'ID card uploaded');
    e.target.value = '';
  };

  return (
    <>
      <PageHead title="Profile" sub={`${user.name} · ${user.rollNo} · ${user.role}`} />

      {isStudent && (
        <div className="card">
          <h3>University ID card</h3>
          {user.idCard?.filename ? (
            <div className="idrow">
              <div><b>{user.idCard.originalName}</b><div className="li-meta">Uploaded {fmtDate(user.idCard.uploadedAt)}</div></div>
              <button className="btn small ghost" onClick={() => setViewing(true)}><Eye size={14} /> View</button>
            </div>
          ) : <div className="empty">Not uploaded yet. The warden needs this to verify you.</div>}
          <label className="drop"><Upload size={18} /> {user.idCard?.filename ? 'Replace ID card' : 'Upload ID card'} (JPG, PNG, WEBP or PDF, max 2 MB)
            <input type="file" hidden accept="image/jpeg,image/png,image/webp,application/pdf" onChange={uploadCard} /></label>
        </div>
      )}

      <div className="card">
        <h3>Details</h3>
        <form onSubmit={saveInfo}>
          <div className="row">
            <div className="field"><label>Phone</label><input name="phone" defaultValue={user.phone} /></div>
            <div className="field"><label>Email</label><input name="email" type="email" defaultValue={user.email} /></div>
          </div>
          {isStudent && <>
            <div className="row">
              <div className="field"><label>Course</label><input name="course" defaultValue={user.course} /></div>
              <div className="field"><label>Year</label><input name="year" defaultValue={user.year} placeholder="e.g. 2nd" /></div>
            </div>
            <div className="row">
              <div className="field"><label>Guardian name</label><input name="guardianName" defaultValue={user.guardianName} /></div>
              <div className="field"><label>Guardian phone</label><input name="guardianPhone" defaultValue={user.guardianPhone} /></div>
            </div>
            <div className="li-meta mb">Room: {user.room ? `Block ${user.room.block}, ${user.room.number}` : 'not allotted — choose one from the Rooms page'}</div>
          </>}
          <button className="btn primary">Save changes</button>
        </form>
      </div>

      <div className="card">
        <h3>Change password</h3>
        <form onSubmit={savePass}>
          <div className="row">
            <div className="field"><label>Current password</label><input name="current" type="password" required /></div>
            <div className="field"><label>New password</label><input name="next" type="password" minLength={6} required /></div>
          </div>
          <button className="btn primary">Update password</button>
        </form>
      </div>
      {viewing && <IdCardViewer userId={user._id} name={user.name} onClose={() => setViewing(false)} />}
    </>
  );
}
