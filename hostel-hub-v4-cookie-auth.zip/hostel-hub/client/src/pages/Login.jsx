import { useState } from 'react';
import { Eye, EyeOff, ShieldCheck, Upload } from 'lucide-react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { UNIVERSITY, PHOTOS } from '../config';

export default function Login() {
  const { startSession } = useAuth();
  const [mode, setMode] = useState('login');
  const [role, setRole] = useState('student');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ kind: '', text: '' });
  const [file, setFile] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setMsg({ kind: '', text: '' });
    const f = Object.fromEntries(new FormData(e.target));
    try {
      let res;
      if (mode === 'login') {
        res = await api.post('/auth/login', { rollNo: f.rollNo, password: f.password });
      } else {
        const body = new FormData(e.target);
        body.set('role', role);
        if (file) body.set('idCard', file); else body.delete('idCard');
        res = await api.post('/auth/register', body);
      }
      startSession(res.data);
    } catch (err) {
      setMsg({ kind: 'err', text: errMsg(err) });
    } finally { setBusy(false); }
  };

  return (
    <div className="login" style={{ backgroundImage: `url(${PHOTOS.campus})` }}>
      <div className="login-shade" />

      <section className="login-story">
        <div className="login-brand">
          <img src={UNIVERSITY.logo} alt={`${UNIVERSITY.name} crest`} height="64" />
          <div>
            <div className="login-uni">{UNIVERSITY.name}</div>
            <div className="login-addr">{UNIVERSITY.hostel} · {UNIVERSITY.address}</div>
          </div>
        </div>

        <h1>Your hostel, handled in one place.</h1>
        <p>Choose your room, raise a complaint, book a washing machine, invite a visitor or order from the canteen. Wardens see it the moment you do.</p>

        <div className="login-photos">
          {[['Library', PHOTOS.library], ['Hostel rooms', PHOTOS.room], ['Canteen', PHOTOS.canteen]].map(([label, src]) => (
            <figure key={label}><img src={src} alt={label} loading="lazy" onError={(e) => (e.currentTarget.parentElement.style.display = 'none')} /><figcaption>{label}</figcaption></figure>
          ))}
        </div>
      </section>

      <section className="login-card">
        <div className="tabs">
          <button className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setMsg({}); }}>Log in</button>
          <button className={mode === 'signup' ? 'active' : ''} onClick={() => { setMode('signup'); setMsg({}); }}>Sign up</button>
        </div>

        <form onSubmit={submit} key={mode} encType="multipart/form-data">
          {mode === 'signup' && (
            <div className="field">
              <label>I am a</label>
              <div className="seg">
                {['student', 'warden', 'admin'].map((r) => (
                  <button type="button" key={r} className={role === r ? 'active' : ''} onClick={() => setRole(r)}>{r}</button>
                ))}
              </div>
            </div>
          )}

          {mode === 'signup' && (
            <div className="row">
              <div className="field"><label>Full name</label><input name="name" required autoComplete="name" /></div>
              <div className="field"><label>{role === 'student' ? 'Roll number' : 'Staff number'}</label><input name="rollNo" required placeholder={role === 'student' ? 'e.g. 21CS045' : 'e.g. W222'} /></div>
            </div>
          )}
          {mode === 'login' && <div className="field"><label>Roll / staff number</label><input name="rollNo" placeholder="e.g. 21CS045" required autoComplete="username" /></div>}

          {mode === 'signup' && (
            <div className="row">
              <div className="field"><label>Phone</label><input name="phone" inputMode="numeric" maxLength={10} placeholder="10-digit" /></div>
              {role === 'student'
                ? <div className="field"><label>Course</label><input name="course" placeholder="e.g. B.Tech CSE" /></div>
                : <div className="field"><label>Email <span className="opt">(optional)</span></label><input name="email" type="email" placeholder="name@pit.ac.in" /></div>}
            </div>
          )}

          <div className="field">
            <label>Password</label>
            <div className="pw">
              <input name="password" type={show ? 'text' : 'password'} required minLength={mode === 'signup' ? 6 : 1} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
              <button type="button" className="icon-btn" onClick={() => setShow(!show)} aria-label="Show password">{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
            </div>
          </div>

          {mode === 'signup' && role === 'student' && (
            <div className="field">
              <label>University ID card <span className="opt">(optional now, JPG / PNG / PDF, max 2 MB)</span></label>
              <label className="drop">
                <Upload size={18} /> {file ? file.name : 'Choose a file'}
                <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" hidden onChange={(e) => setFile(e.target.files[0] || null)} />
              </label>
            </div>
          )}

          <button className="btn primary block" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Create account'}</button>
          {msg.text && <div className={`msg ${msg.kind}`}>{msg.text}</div>}
        </form>

        <div className="secure"><ShieldCheck size={15} /> Passwords are encrypted. Your ID card is visible only to you and hostel staff.</div>
        {mode === 'login' && <div className="hint">Demo — warden <code>WARDEN01</code> / <code>warden123</code> · admin <code>ADMIN01</code> / <code>admin123</code></div>}
      </section>
    </div>
  );
}
