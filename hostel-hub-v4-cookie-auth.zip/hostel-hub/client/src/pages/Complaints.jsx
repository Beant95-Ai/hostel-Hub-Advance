import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Badge, Empty, Hero, fmtDate } from '../components/ui';
import { PHOTOS } from '../config';

const CATS = ['Electrical', 'Plumbing', 'Internet', 'Furniture', 'Cleaning', 'Other'];

export default function Complaints() {
  const { user } = useAuth();
  const toast = useToast();
  const isStaff = user.role !== 'student';
  const { data, reload } = useData('/complaints', ['complaints']);

  const submit = async (e) => {
    e.preventDefault();
    try { await api.post('/complaints', Object.fromEntries(new FormData(e.target))); toast('Complaint submitted'); e.target.reset(); reload(); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  const setStatus = (id, status) => api.patch(`/complaints/${id}`, { status }).then(() => toast('Status updated')).catch((e) => toast(errMsg(e), 'err'));

  return (
    <>
      <Hero image={PHOTOS.library} title={isStaff ? 'Complaint control room' : 'Complaint centre'}
        sub={isStaff ? 'Pick up issues, update progress and close them.' : 'Report a problem and follow it until it is fixed.'} />

      {!isStaff && (
        <div className="card">
          <h3>Raise a complaint</h3>
          <form onSubmit={submit}>
            <div className="row">
              <div className="field"><label>Title</label><input name="title" required placeholder="e.g. Ceiling fan not working" /></div>
              <div className="field"><label>Category</label><select name="category">{CATS.map((c) => <option key={c}>{c}</option>)}</select></div>
            </div>
            <div className="field"><label>Details</label><textarea name="desc" required placeholder="What is wrong, where, and how urgent is it?" /></div>
            <button className="btn primary">Submit complaint</button>
          </form>
        </div>
      )}

      <div className="card">
        <h3>{isStaff ? 'All complaints' : 'Your complaints'}</h3>
        {!data ? <Empty>Loading…</Empty> : !data.length ? <Empty>No complaints yet.</Empty> : data.map((c) => (
          <div className="list-item" key={c._id}>
            <div className="li-main">
              <div className="li-title">{c.title} <span className="chip">{c.category}</span></div>
              <div className="li-desc">{c.desc}</div>
              <div className="li-meta">{isStaff && `${c.student?.name} · ${c.student?.rollNo}${c.student?.room ? ` · Room ${c.student.room.number}` : ''} · `}{fmtDate(c.createdAt)}</div>
            </div>
            <div className="li-side">
              <Badge status={c.status} />
              {isStaff && (
                <select value={c.status} onChange={(e) => setStatus(c._id, e.target.value)}>
                  <option value="pending">pending</option><option value="in-progress">in-progress</option><option value="resolved">resolved</option>
                </select>
              )}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
