import { useState } from 'react';
import { FileText, Paperclip, Trash2 } from 'lucide-react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Badge, Empty, Hero, fmtDate } from '../components/ui';
import { PHOTOS } from '../config';

export default function Notices() {
  const { user } = useAuth();
  const toast = useToast();
  const isStaff = user.role !== 'student';
  const { data, reload } = useData('/notices', ['notices']);
  const [file, setFile] = useState(null);
  const [filter, setFilter] = useState('all');

  const submit = async (e) => {
    e.preventDefault();
    const body = new FormData(e.target);
    if (file) body.set('attachment', file); else body.delete('attachment');
    try { await api.post('/notices', body); toast('Published'); e.target.reset(); setFile(null); reload(); }
    catch (err) { toast(errMsg(err), 'err'); }
  };
  const remove = (id) => api.delete(`/notices/${id}`).then(() => toast('Deleted')).catch((e) => toast(errMsg(e), 'err'));
  const list = (data || []).filter((n) => filter === 'all' || n.category === filter);

  return (
    <>
      <Hero image={PHOTOS.library} title="Notices & circulars" sub="Every announcement from the warden's office, with the original document attached." />

      {isStaff && (
        <div className="card">
          <h3>Publish a notice or circular</h3>
          <form onSubmit={submit}>
            <div className="row">
              <div className="field"><label>Title</label><input name="title" required /></div>
              <div className="field"><label>Type</label><select name="category"><option value="notice">Notice</option><option value="circular">Circular</option><option value="urgent">Urgent</option></select></div>
            </div>
            <div className="field"><label>Details</label><textarea name="desc" required /></div>
            <div className="field">
              <label>Attachment <span className="opt">(PDF, Word or image, max 5 MB)</span></label>
              <label className="drop"><Paperclip size={18} /> {file ? file.name : 'Attach a file'}
                <input type="file" hidden accept=".pdf,.doc,.docx,image/jpeg,image/png,image/webp" onChange={(e) => setFile(e.target.files[0] || null)} /></label>
            </div>
            <button className="btn primary">Publish</button>
          </form>
        </div>
      )}

      <div className="seg wrap">{['all', 'notice', 'circular', 'urgent'].map((f) => <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>{f}</button>)}</div>

      <div className="notes">
        {!data ? <Empty>Loading…</Empty> : !list.length ? <Empty>Nothing posted here yet.</Empty> : list.map((n) => (
          <article className={`note ${n.category}`} key={n._id}>
            <div className="note-top"><Badge status={n.category} />
              {isStaff && (user.role === 'admin' || n.by?._id === user._id) && <button className="icon-btn" onClick={() => remove(n._id)} aria-label="Delete"><Trash2 size={16} /></button>}</div>
            <h4>{n.title}</h4>
            <p>{n.desc}</p>
            {n.attachment?.mimetype?.startsWith('image/') && (
              <a href={`/uploads/notices/${n.attachment.filename}`} target="_blank" rel="noreferrer"><img className="note-img" src={`/uploads/notices/${n.attachment.filename}`} alt={n.attachment.originalName} /></a>
            )}
            {n.attachment?.filename && (
              <a className="attach" href={`/uploads/notices/${n.attachment.filename}`} target="_blank" rel="noreferrer"><FileText size={16} /> {n.attachment.originalName}</a>
            )}
            <div className="li-meta">{n.by?.name} · {fmtDate(n.createdAt)}</div>
          </article>
        ))}
      </div>
    </>
  );
}
