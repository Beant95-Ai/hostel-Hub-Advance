import { useMemo, useState } from 'react';
import { BedDouble, Snowflake, Trash2 } from 'lucide-react';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { useData } from '../live';
import { useToast } from '../components/Toast';
import { Empty, Hero, PageHead } from '../components/ui';
import { PHOTOS } from '../config';

export default function Rooms() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const isStaff = user.role !== 'student';
  const { data: rooms, reload } = useData('/rooms', ['rooms']);
  const { data: free } = useData(isStaff ? '/users?role=student&unallotted=1' : null, ['users', 'rooms']);
  const [block, setBlock] = useState('All');
  const [pick, setPick] = useState({});

  const blocks = useMemo(() => ['All', ...new Set((rooms || []).map((r) => r.block))], [rooms]);
  const shown = (rooms || []).filter((r) => block === 'All' || r.block === block);

  const act = async (fn, ok) => {
    try { await fn(); toast(ok); await refresh(); reload(); } catch (e) { toast(errMsg(e), 'err'); }
  };

  const mine = rooms?.find((r) => r._id === user.room?._id);

  return (
    <>
      <Hero image={PHOTOS.room} title="Rooms" sub={isStaff ? 'Create rooms, allot students and watch occupancy live.' : 'Choose a room with a free bed. You can change it any time.'} />

      {!isStaff && (
        <div className="card">
          <h3>Your room</h3>
          {mine ? (
            <div className="myroom">
              <div><div className="big">Block {mine.block} · {mine.number}</div><div className="li-meta">Floor {mine.floor} · {mine.type} · {mine.occupied}/{mine.capacity} beds filled</div></div>
              <div className="mates">{mine.occupants.map((o) => <span key={o._id} className="chip">{o.name}{String(o._id) === user._id ? ' (you)' : ''}</span>)}</div>
              <button className="btn ghost" onClick={() => act(() => api.post('/rooms/vacate'), 'Room vacated')}>Leave this room</button>
            </div>
          ) : <Empty>No room yet. Pick one from the list below.</Empty>}
        </div>
      )}

      {isStaff && <AddRoom onDone={reload} />}

      <PageHead title="All rooms" sub={`${shown.length} shown`}>
        <div className="seg">{blocks.map((b) => <button key={b} className={block === b ? 'active' : ''} onClick={() => setBlock(b)}>{b === 'All' ? 'All blocks' : `Block ${b}`}</button>)}</div>
      </PageHead>

      <div className="room-grid">
        {shown.map((r) => {
          const full = r.occupied >= r.capacity;
          const isMine = r._id === user.room?._id;
          return (
            <div className={`room ${full ? 'full' : ''} ${isMine ? 'mine' : ''}`} key={r._id}>
              <div className="room-top"><b>{r.number}</b><span className="li-meta">Block {r.block} · Floor {r.floor}</span></div>
              <div className="beds">{Array.from({ length: r.capacity }).map((_, i) => <BedDouble key={i} size={20} className={i < r.occupied ? 'on' : ''} />)}</div>
              <div className="li-meta">{r.type === 'AC' && <Snowflake size={12} />} {r.type} · {r.capacity - r.occupied > 0 ? `${r.capacity - r.occupied} free` : 'Full'}</div>

              {isStaff ? (
                <>
                  {r.occupants.map((o) => (
                    <div className="occ" key={o._id}><span>{o.name} <i>{o.rollNo}</i></span>
                      <button className="icon-btn" title="Vacate" onClick={() => act(() => api.post('/rooms/vacate', { studentId: o._id }), 'Student removed from room')}><Trash2 size={14} /></button></div>
                  ))}
                  {!full && (
                    <div className="allot">
                      <select value={pick[r._id] || ''} onChange={(e) => setPick({ ...pick, [r._id]: e.target.value })}>
                        <option value="">Allot a student…</option>
                        {(free || []).map((s) => <option key={s._id} value={s._id}>{s.name} ({s.rollNo})</option>)}
                      </select>
                      <button className="btn small" disabled={!pick[r._id]} onClick={() => act(() => api.post(`/rooms/${r._id}/allot`, { studentId: pick[r._id] }), 'Room allotted')}>Allot</button>
                    </div>
                  )}
                  {user.role === 'admin' && !r.occupied && <button className="btn small ghost" onClick={() => act(() => api.delete(`/rooms/${r._id}`), 'Room deleted')}>Delete room</button>}
                </>
              ) : (
                <button className="btn small" disabled={full || isMine} onClick={() => act(() => api.post(`/rooms/${r._id}/allot`), 'Room allotted')}>
                  {isMine ? 'Your room' : full ? 'Full' : user.room ? 'Move here' : 'Select room'}
                </button>
              )}
            </div>
          );
        })}
      </div>
      {rooms && !shown.length && <Empty>No rooms yet.</Empty>}
    </>
  );
}

function AddRoom({ onDone }) {
  const toast = useToast();
  const submit = async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { await api.post('/rooms', f); toast('Room added'); e.target.reset(); onDone(); } catch (err) { toast(errMsg(err), 'err'); }
  };
  return (
    <div className="card">
      <h3>Add a room</h3>
      <form onSubmit={submit} className="row4">
        <div className="field"><label>Block</label><input name="block" required placeholder="A" /></div>
        <div className="field"><label>Room no.</label><input name="number" required placeholder="A101" /></div>
        <div className="field"><label>Floor</label><input name="floor" type="number" min="0" defaultValue="1" /></div>
        <div className="field"><label>Beds</label><input name="capacity" type="number" min="1" max="6" defaultValue="3" /></div>
        <div className="field"><label>Type</label><select name="type"><option>Non-AC</option><option>AC</option></select></div>
        <button className="btn primary">Add room</button>
      </form>
    </div>
  );
}
