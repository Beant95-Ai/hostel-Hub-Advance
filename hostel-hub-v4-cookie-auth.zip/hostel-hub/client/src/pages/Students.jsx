import { useEffect, useState } from 'react';
import { BadgeCheck, Eye } from 'lucide-react';
import { useData } from '../live';
import { Empty, IdCardViewer, PageHead } from '../components/ui';

export default function Students() {
  const [q, setQ] = useState('');
  const [debounced, setDebounced] = useState('');
  useEffect(() => { const t = setTimeout(() => setDebounced(q), 250); return () => clearTimeout(t); }, [q]);
  const { data } = useData(`/users?role=student&q=${encodeURIComponent(debounced)}`, ['users', 'rooms']);
  const [view, setView] = useState(null);

  return (
    <>
      <PageHead title="Students" sub={data ? `${data.length} found · updates live as students register` : ''}>
        <input className="search" placeholder="Search name, roll number or course" value={q} onChange={(e) => setQ(e.target.value)} />
      </PageHead>
      <div className="card flush">
        <div className="scroll">
          <table className="table">
            <thead><tr><th>Student</th><th>Roll no.</th><th>Course</th><th>Room</th><th>Phone</th><th>ID card</th></tr></thead>
            <tbody>
              {(data || []).map((s) => (
                <tr key={s._id}>
                  <td><b>{s.name}</b></td><td>{s.rollNo}</td><td>{s.course || '—'}</td>
                  <td>{s.room ? `${s.room.block}-${s.room.number}` : <span className="dim">Not allotted</span>}</td>
                  <td>{s.phone || '—'}</td>
                  <td>{s.idCard?.filename
                    ? <button className="btn small ghost" onClick={() => setView(s)}><Eye size={14} /> View</button>
                    : <span className="dim">Missing</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data && !data.length && <Empty>No students match.</Empty>}
      </div>
      {view && <IdCardViewer userId={view._id} name={view.name} onClose={() => setView(null)} />}
    </>
  );
}
