import { useEffect, useRef, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import api, { errMsg } from './api';

let socket = null;

export function connectSocket() {
  // the "token" cookie is sent automatically, so no token needed here
  if (!localStorage.getItem('currentUser') || socket) return socket;
  socket = io({ withCredentials: true });
  return socket;
}
export function disconnectSocket() { socket?.disconnect(); socket = null; }

// Re-run `fn` whenever the server says one of `types` changed (real-time).
export function useLive(types, fn) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    const s = connectSocket();
    if (!s) return;
    const handler = ({ type }) => types.includes(type) && ref.current();
    s.on('update', handler);
    return () => s.off('update', handler);
  }, []); // eslint-disable-line
}

// GET a path and keep it fresh in real time.
export function useData(path, types = []) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const load = useCallback(() => !path ? Promise.resolve() : api.get(path).then((r) => { setData(r.data); setError(''); }).catch((e) => setError(errMsg(e))), [path]);
  useEffect(() => { setData(null); load(); }, [load]);
  useLive(types, load);
  return { data, error, reload: load, loading: data === null && !error };
}
